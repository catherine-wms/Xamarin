﻿using UIKit;

namespace XamlMvvm.iOS
{
    public class Application
    {
        static void Main(string[] args) => UIApplication.Main(args, null, nameof(AppDelegate));
    }
}
