﻿using Xamarin.Forms;

namespace CodedUIMvvm
{
    public class App : Application
    {
        public App()
        {
            MainPage = new MainPage();
        }
    }
}
