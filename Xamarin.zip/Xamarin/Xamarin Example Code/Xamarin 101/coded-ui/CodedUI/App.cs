﻿using Xamarin.Forms;

namespace CodedUI
{
    public class App : Application
    {
        public App()
        {
            MainPage = new MainPage();
        }
    }
}
