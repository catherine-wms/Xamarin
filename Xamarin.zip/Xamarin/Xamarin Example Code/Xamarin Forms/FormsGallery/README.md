---
name: Xamarin.Forms - FormsGallery
description: This program displays all the views, cells, layouts, and pages available in Xamarin.Forms.
page_type: sample
languages:
- csharp
products:
- xamarin
urlFragment: formsgallery
---
# FormsGallery

This program displays all the views, cells, layouts, and pages available in Xamarin.Forms, one per page.

![FormsGallery application screenshot](Screenshots/Button.png "FormsGallery application screenshot")

