---
name: Xamarin.Forms - LabelledSections
description: This sample demonstrates how to create an alphabetically ordered list with labelled sections. LabelledSections is based off of...
page_type: sample
languages:
- csharp
products:
- xamarin
urlFragment: labelledsectionslist
---
# LabelledSections

This sample demonstrates how to create an alphabetically ordered list with labelled sections.

LabelledSections is based off of https://github.com/xamarin/monodroid-samples/tree/master/LabelledSections

![LabelledSections application screenshot](Screenshots/LabelledSections_Android.png "LabelledSections application screenshot")

