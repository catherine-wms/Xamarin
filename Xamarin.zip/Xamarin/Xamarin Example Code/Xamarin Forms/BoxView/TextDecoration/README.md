---
name: Xamarin.Forms - Text Decoration
description: One simple application of the BoxView element is for adorning text with horizontal and vertical lines. This sample is described in more detail in...
page_type: sample
languages:
- csharp
products:
- xamarin
urlFragment: boxview-textdecoration
---
# Text Decoration

One simple application of the `BoxView` element is for adorning text with horizontal and vertical lines.

This sample is described in more detail in the article on [BoxView](https://docs.microsoft.com/xamarin/xamarin-forms/user-interface/boxview).

![Text Decoration application screenshot](Screenshots/01All.png "Text Decoration application screenshot")
