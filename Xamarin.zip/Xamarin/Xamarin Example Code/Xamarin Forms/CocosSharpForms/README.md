# CocosSharp and Xamarin Forms

This solution contains an iOS and Android project which combines CocosSharp with Xamarin Forms. All code (aside from initial template code) is contained in a .NET Standard Library.

This demo is built against CocosSharp 1.7.1

![CocosSharp and Xamarin Forms application screenshot](Screenshots/01WinPhone.png "CocosSharp and Xamarin Forms application screenshot")

