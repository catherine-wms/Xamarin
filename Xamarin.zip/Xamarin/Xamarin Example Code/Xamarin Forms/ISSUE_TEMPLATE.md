### Sample

<!-- Provide a link to the sample there’s an issue with e.g. https://github.com/xamarin/xamarin-forms-samples/tree/master/WebServices/TodoREST -->

### Description

<!-- Describe what the issue is -->

### Steps to Reproduce

1.
2.
3.

### Expected Behavior


### Actual Behavior


### Information

- IDE and IDE version: <!-- Visual Studio 2017 v15.6 / Visual Studio Mac v7.4 -->
- Platform with the issue: <!-- All that apply -->
  - iOS:  <!-- The version of the iOS SDK you are compiling against, e.g. 11.1 -->
  - Android: <!-- The version of the Android SDK you are compiling against, e.g. 8.0 -->
  - UWP:  <!-- The version of the UWP SDK you are compiling against, e.g. 16299 -->
- Device or simulator/emulator: <!-- State whether the problem occurs on a device or a simulator/emulator -->
