---
name: Xamarin.Forms - Notes (styled)
description: "A Xamarin.Forms application that's styled with XAML styles (get started)"
page_type: sample
languages:
- csharp
products:
- xamarin
extensions:
    tags:
    - getstarted
urlFragment: getstarted-notes-styled
---
# Notes (styled)

This sample demonstrates a Xamarin.Forms application that's styled with XAML styles.

For more information about the sample see [Style a Cross-Platform Xamarin.Forms Application](https://docs.microsoft.com/xamarin/get-started/quickstarts/styled).

![Notes (styled) application screenshot](Screenshots/01All.png "Notes (styled) application screenshot")

