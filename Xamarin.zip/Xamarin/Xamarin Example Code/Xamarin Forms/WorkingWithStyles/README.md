---
name: Xamarin.Forms - Working with Styles
description: "This sample relates to the Working with styles in Xamarin.Forms doc (UI)"
page_type: sample
languages:
- csharp
products:
- xamarin
extensions:
    tags:
    - ui
urlFragment: workingwithstyles
---
# Working with Styles in Xamarin.Forms

This sample relates to the [Working with Styles in Xamarin.Forms](https://docs.microsoft.com/xamarin/xamarin-forms/user-interface/styles/) doc.

![Working with Styles application screenshot](Screenshots/Android.png "Working with Styles application screenshot")

