---
name: Xamarin.Forms - Slider Demos
description: "This program demonstrates the Xamarin.Forms Slider in code, XAML with code-behind, and XAML data-binding scenarios (UI)"
page_type: sample
languages:
- csharp
products:
- xamarin
extensions:
    tags:
    - ui
urlFragment: userinterface-sliderdemos
---
# Slider Demos

This program demonstrates the Xamarin.Forms Slider in code, XAML with code-behind, and XAML data-binding scenarios.

![Slider Demos application screenshot](Screenshots/01BasicSliderCode-Large.png "Slider Demos application screenshot")

