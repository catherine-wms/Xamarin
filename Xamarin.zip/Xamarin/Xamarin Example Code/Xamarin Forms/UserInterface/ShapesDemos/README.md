---
name: Xamarin.Forms - Shapes
description: "This sample demonstrates how to use Xamarin.Forms Shapes (UI)"
page_type: sample
languages:
- csharp
products:
- xamarin
extensions:
    tags:
    - ui
urlFragment: userinterface-shapesdemos
---
# Shapes

This sample demonstrates how to use Xamarin.Forms Shapes, to draw shapes.

For more information about this sample, see [Xamarin.Forms Shapes](https://docs.microsoft.com/xamarin/xamarin-forms/user-interface/shapes/).

![Shapes demos application screenshot](Screenshots/01All.png "Shapes demos application screenshot")
