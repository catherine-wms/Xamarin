---
name: Xamarin.Forms - Modal Pages
description: "This sample demonstrates how to navigate to modal pages (navigation)"
page_type: sample
languages:
- csharp
products:
- xamarin
urlFragment: navigation-modal
---
# Modal Pages

This sample demonstrates how to navigate to modal pages.

For more information about the sample see [Modal Pages](https://docs.microsoft.com/xamarin/xamarin-forms/app-fundamentals/navigation/modal).

![Modal Pages application screenshot](Screenshots/01All.png "Modal Pages application screenshot")

