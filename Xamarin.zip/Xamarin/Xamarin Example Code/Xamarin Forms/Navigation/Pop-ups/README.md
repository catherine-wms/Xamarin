---
name: Xamarin.Forms - Displaying Pop-ups
description: "This sample demonstrates using the alert and action sheet APIs to ask users simple questions and guide users through tasks (navigation)"
page_type: sample
languages:
- csharp
products:
- xamarin
urlFragment: navigation-pop-ups
---
# Displaying Pop-ups

This sample demonstrates using the alert and action sheet APIs to ask users simple questions and guide users through tasks.

For more information about the sample see [Displaying Pop-ups](https://docs.microsoft.com/xamarin/xamarin-forms/user-interface/pop-ups).

![Displaying Pop-ups application screenshot](Screenshots/01All.png "Displaying Pop-ups application screenshot")

