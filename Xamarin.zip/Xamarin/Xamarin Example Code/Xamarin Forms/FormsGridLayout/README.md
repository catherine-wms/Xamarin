---
name: Xamarin.Forms - GridLayoutDemo
description: This sample demonstrates how to display various ui elements in a grid. GridLayoutDemo is based off of...
page_type: sample
languages:
- csharp
products:
- xamarin
urlFragment: formsgridlayout
---
# GridLayoutDemo

This sample demonstrates how to display various ui elements in a grid.

GridLayoutDemo is based off of https://github.com/xamarin/monodroid-samples/tree/master/GridLayoutDemo

![GridLayoutDemo application screenshot](Screenshots/GridLayoutAndroid.png "GridLayoutDemo application screenshot")

