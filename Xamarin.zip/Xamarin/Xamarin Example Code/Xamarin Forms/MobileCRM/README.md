Xamarin CRM (Xamarin.Forms)
===========

Please visit the new [**Xamarin CRM sample**](https://github.com/xamarin/app-crm).

This sample has been deprecated and is no longer supported.

